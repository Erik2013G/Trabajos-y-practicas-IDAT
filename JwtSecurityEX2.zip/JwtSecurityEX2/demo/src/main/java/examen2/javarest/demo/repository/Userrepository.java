package examen2.javarest.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import examen2.javarest.demo.entity.User;

public interface Userrepository extends JpaRepository<User, Long> { 
}
