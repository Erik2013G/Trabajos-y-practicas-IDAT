package examen2.javarest.demo.repository;

public interface Rolerepository {

}
