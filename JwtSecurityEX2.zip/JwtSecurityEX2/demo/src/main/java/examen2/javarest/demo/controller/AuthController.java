package examen2.javarest.demo.controller;

public class AuthController {

}
