package examen2.javarest.demo.service.impl;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import examen2.javarest.demo.entity.User;
import examen2.javarest.demo.repository.Userrepository;

@Service
// Implementación del UserDetailsService para autenticar usuarios
public class UserDetailsServiceimpl extends UserDetailsService {
    private final Userrepository userRepository;

    public UserDetailsServiceimpl(Userrepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("Usuario no encontrado: " + username));
        return user;
    }
}
