package examen2.javarest.demo.config;

public class SecurityConfig {

}
