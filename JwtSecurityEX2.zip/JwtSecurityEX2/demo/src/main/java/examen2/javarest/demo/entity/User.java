package examen2.javarest.demo.entity;

public class User {

}
