package examen2.javarest.demo.service;

public interface JwtService {

}
