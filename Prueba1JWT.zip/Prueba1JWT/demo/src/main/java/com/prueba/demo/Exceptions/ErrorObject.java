package com.prueba.demo.Exceptions;

import java.util.Date;

/**
 * Esta clase se utiliza para encapsular y manejar los errores que puedan surgir durante la ejecución de la API.
 * @author grik
 */
public class ErrorObject {
    private Integer statuscode;
    private String message;
    private String details;
    private Date timestamp;
    
    public ErrorObject(Integer statuscode, String message, String details, Date timestamp) {
        this.statuscode = statuscode;
        this.message = message;
        this.details = details;
        this.timestamp = timestamp;
    }
    public Integer getStatuscode() {
        return statuscode;
    }
    public void setStatuscode(Integer statuscode) {
        this.statuscode = statuscode;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public String getDetails() {
        return details;
    }
    public void setDetails(String details) {
        this.details = details;
    }
    public Date getTimestamp() {
        return timestamp;
    }
}
