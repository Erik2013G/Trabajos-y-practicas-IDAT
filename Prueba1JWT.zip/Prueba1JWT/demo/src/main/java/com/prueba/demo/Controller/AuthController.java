package com.prueba.demo.Controller;

public class AuthController {

}
