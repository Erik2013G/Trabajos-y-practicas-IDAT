package com.prueba.demo.Exceptions;

public class NotFoundException {

}
