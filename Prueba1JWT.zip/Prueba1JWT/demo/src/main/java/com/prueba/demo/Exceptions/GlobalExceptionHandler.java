package com.prueba.demo.Exceptions;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;

public class GlobalExceptionHandler {
    @ExceptionHandler(ResourceNotFoundException.class)
public ResponseEntity<ErrorObject> handleResourceNotFound(ResourceNotFoundException ex) {
    ErrorObject error = new ErrorObject(
        HttpStatus.NOT_FOUND.value(),
        ex.getMessage(),
        "El recurso solicitado no está disponible",
        new Date(System.currentTimeMillis())
    );
    return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
}
}
