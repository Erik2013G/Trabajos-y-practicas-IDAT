package com.prueba.demo.Exceptions;

public class JwtAuthenticationException {

}
