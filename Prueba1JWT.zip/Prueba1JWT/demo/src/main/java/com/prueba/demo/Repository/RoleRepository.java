package com.prueba.demo.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prueba.demo.Entity.Rol;

public interface RoleRepository extends JpaRepository<Rol,Long> {
    Optional<Rol> findByNombreRol(String nombreRol);  // Buscar por nombre
List<Rol> findAllByNombreRolContaining(String keyword);  // Buscar por palabra clave
boolean existsByNombreRol(String nombreRol);  // Verificar si existe
void deleteByNombreRol(String nombreRol);  // Eliminar por nombre
}